import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Provider as PaperProvider } from 'react-native-paper';
import HomeScreen from './screens/HomeScreen';
import CourseMapScreen from './screens/CourseMapScreen';
import ScorecardScreen from './screens/ScorecardScreen';
import GameHistoryScreen from './screens/GameHistoryScreen';
import SettingsScreen from './screens/SettingsScreen';
import { GameProvider } from './contexts/GameContext';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <PaperProvider>
      <GameProvider>
        <NavigationContainer>
          <Tab.Navigator initialRouteName="Home">
            <Tab.Screen name="Home" component={HomeScreen} />
            <Tab.Screen name="Map" component={CourseMapScreen} />
            <Tab.Screen name="Scorecard" component={ScorecardScreen} />
            <Tab.Screen name="History" component={GameHistoryScreen} />
            <Tab.Screen name="Settings" component={SettingsScreen} />
          </Tab.Navigator>
        </NavigationContainer>
      </GameProvider>
    </PaperProvider>
  );
}
