import React from 'react';
import { View } from 'react-native';
import { Text, Switch } from 'react-native-paper';

export default function SettingsScreen() {
  const [dark, setDark] = React.useState(false);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text>Dark Mode</Text>
      <Switch value={dark} onValueChange={setDark} />
    </View>
  );
}
