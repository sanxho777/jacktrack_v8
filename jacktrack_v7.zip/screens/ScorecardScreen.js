import React, { useContext } from 'react';
import { View, FlatList, TextInput, StyleSheet } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { GameContext } from '../contexts/GameContext';

export default function ScorecardScreen() {
  const { game, setGame } = useContext(GameContext);
  const updateScore = (i, v) => {
    const scores = [...game.scores];
    scores[i] = v;
    setGame({ ...game, scores });
  };
  return (
    <View style={styles.container}>
      <FlatList
        data={game.scores}
        keyExtractor={(_, i) => i.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.row}>
            <Text>Hole {index + 1}</Text>
            <TextInput style={styles.input} keyboardType="numeric" value={item} onChangeText={v => updateScore(index, v)} />
          </View>
        )}
      />
      <Button mode="contained" onPress={() => alert('Scores saved!')}>Save Scores</Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  input: { borderWidth: 1, width: 50, textAlign: 'center' }
});
