import React, { useContext } from 'react';
import { View } from 'react-native';
import { Button, Card, Text } from 'react-native-paper';
import { GameContext } from '../contexts/GameContext';

export default function HomeScreen({ navigation }) {
  const { game, setGame } = useContext(GameContext);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Button mode="contained" onPress={() => setGame({ scores: Array(18).fill(''), balls: [] })}>
        New Game
      </Button>
      <Text style={{ marginVertical: 16, fontSize: 18 }}>Current Game</Text>
      <Card onPress={() => navigation.navigate('Map')}>
        <Card.Content>
          <Text>Holes scored: {game.scores.filter(s => s).length}</Text>
        </Card.Content>
      </Card>
      <Text style={{ marginVertical: 16, fontSize: 18 }}>Options</Text>
      <Button onPress={() => navigation.navigate('Settings')}>Settings</Button>
    </View>
  );
}
