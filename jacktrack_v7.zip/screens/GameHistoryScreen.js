import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Text } from 'react-native-paper';

const dummyHistory = [
  { id: '1', date: '2025-07-20', score: '72' },
  { id: '2', date: '2025-07-18', score: '68' },
];

export default function GameHistoryScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={dummyHistory}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text>{item.date}</Text>
            <Text>Score: {item.score}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }
});
