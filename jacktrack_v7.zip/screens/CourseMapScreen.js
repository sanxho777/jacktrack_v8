import React, { useEffect, useState, useContext } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { BleManager } from 'react-native-ble-plx';
import { GameContext } from '../contexts/GameContext';

export default function CourseMapScreen() {
  const [region] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const { game, setGame } = useContext(GameContext);

  useEffect(() => {
    const manager = new BleManager();
    manager.startDeviceScan(null, null, (error, device) => {
      if (device && device.name?.startsWith('BallBeacon')) {
        const newBall = { id: device.id, latitude: region.latitude + 0.0005, longitude: region.longitude + 0.0005 };
        setGame({ ...game, balls: [...game.balls, newBall] });
      }
    });
    return () => manager.stopDeviceScan();
  }, [game, region.latitude, region.longitude, setGame]);

  return (
    <View style={styles.container}>
      <MapView style={styles.map} region={region}>
        {game.balls.map(ball => (
          <Marker key={ball.id} coordinate={ball} title="Golf Ball" pinColor="blue" />
        ))}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { width: Dimensions.get('window').width, height: Dimensions.get('window').height }
});
