import AsyncStorage from '@react-native-async-storage/async-storage';
const GAME_KEY = 'JACKTRACK_GAME';

export default {
  saveGame: async (game) => {
    try {
      await AsyncStorage.setItem(GAME_KEY, JSON.stringify(game));
    } catch (e) {
      console.error('Failed to save game', e);
    }
  },
  loadGame: async () => {
    try {
      const json = await AsyncStorage.getItem(GAME_KEY);
      return json != null ? JSON.parse(json) : null;
    } catch (e) {
      console.error('Failed to load game', e);
      return null;
    }
  },
};
