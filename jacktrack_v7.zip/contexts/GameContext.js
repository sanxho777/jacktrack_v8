import React, { createContext, useState, useEffect } from 'react';
import StorageService from '../services/storage';

export const GameContext = createContext();

export function GameProvider({ children }) {
  const [game, setGame] = useState({ scores: [], balls: [] });

  useEffect(() => {
    (async () => {
      const saved = await StorageService.loadGame();
      if (saved) setGame(saved);
    })();
  }, []);

  useEffect(() => {
    StorageService.saveGame(game);
  }, [game]);

  return (
    <GameContext.Provider value={{ game, setGame }}>
      {children}
    </GameContext.Provider>
  );
}
