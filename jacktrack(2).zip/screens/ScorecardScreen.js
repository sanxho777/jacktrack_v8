import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet } from 'react-native';

export default function ScorecardScreen() {
  const [scores, setScores] = useState(Array(18).fill(''));
  const updateScore = (index, value) => {
    const newScores = [...scores];
    newScores[index] = value;
    setScores(newScores);
  };
  return (
    <View style={styles.container}>
      <FlatList
        data={scores}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.row}>
            <Text>Hole {index + 1}</Text>
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              value={item}
              onChangeText={val => updateScore(index, val)}
            />
          </View>
        )}
      />
      <Button title="Save Scores" onPress={() => alert('Scores saved!')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  input: { borderWidth: 1, width: 50, textAlign: 'center' }
});
