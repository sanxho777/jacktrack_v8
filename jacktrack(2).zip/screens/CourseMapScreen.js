import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { BleManager } from 'react-native-ble-plx';

export default function CourseMapScreen() {
  const [region, setRegion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [balls, setBalls] = useState([]);
  useEffect(() => {
    const manager = new BleManager();
    // BLE scanning for ball beacons
    manager.startDeviceScan(null, null, (error, device) => {
      if (device && device.name?.startsWith('BallBeacon')) {
        // Simulate coordinates for demo
        setBalls(prev => [...prev, { id: device.id, latitude: region.latitude + 0.0005, longitude: region.longitude + 0.0005 }]);
      }
    });
    return () => manager.stopDeviceScan();
  }, []);

  return (
    <View style={styles.container}>
      <MapView style={styles.map} region={region}>
        {balls.map(ball => (
          <Marker
            key={ball.id}
            coordinate={{ latitude: ball.latitude, longitude: ball.longitude }}
            title="Golf Ball"
            pinColor="blue"
          />
        ))}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { width: Dimensions.get('window').width, height: Dimensions.get('window').height }
});
