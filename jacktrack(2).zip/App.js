import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import CourseMapScreen from './screens/CourseMapScreen';
import ScorecardScreen from './screens/ScorecardScreen';
import GameHistoryScreen from './screens/GameHistoryScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator initialRouteName="Map">
        <Tab.Screen name="Map" component={CourseMapScreen} />
        <Tab.Screen name="Scorecard" component={ScorecardScreen} />
        <Tab.Screen name="History" component={GameHistoryScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
